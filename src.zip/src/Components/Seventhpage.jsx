import React from "react";

const Seventh =() =>{
    return(
        <>
         <div className="group-13">
    <div className="l-constrained">
      <p className="text-50">
        We are Ready to Take Your Call 24 Hours, 7 Days!
      </p>
      <p className="text-51">+123 4567 8900</p>
    </div>
  </div>
        </>
    )
}
export default Seventh